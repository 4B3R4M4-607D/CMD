#!/usr/bin/env bash
# clean_cmd.sh — hapus semua artefak hasil build, sisakan file SUMBER saja.
# Dir ini khusus amunisi upload, jadi "artefak" = semua file yang bukan sumber.
set -euo pipefail
cd "$(dirname "$0")"

# Daftar putih: SEMUA file yang bukan artefak. Update di sini kalau ada sumber baru.
KEEP_RE='^(build_cmd\.sh|build_shells\.sh|build_all\.sh|clean_cmd\.sh|verify_cmd\.sh|selfcheck\.py|imgmagic\.py|payloads\.txt|ext_core\.txt|ext_poly\.txt|ext_double\.txt|ext_trailing\.txt|README\.md|\.canary_saya)$'

n=0
while IFS= read -r -d '' f; do
  f=${f#./}
  if [[ "$f" =~ $KEEP_RE ]]; then continue; fi
  rm -f -- "$f"
  n=$((n+1))
done < <(find . -maxdepth 1 -type f -print0)

echo "dihapus: $n file | tersisa:"
ls -1a | grep -v '^\.$\|^\.\.$'