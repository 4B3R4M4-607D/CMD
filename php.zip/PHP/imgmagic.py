#!/usr/bin/env python3
"""imgmagic.py — tulis header image yang BENAR-BENAR valid ke stdout.

Dipakai oleh build_cmd.sh supaya header binary (yang penuh byte NUL) tidak pernah
melewati command substitution bash -- $(...) membuang NUL dan merusak header.

Pakai:
    python3 imgmagic.py png > header.bin
    python3 imgmagic.py jpg > header.bin
Jenis: png gif jpg bmp wbmp xbm svg pdf
"""
import struct
import sys

# PNG 1x1 grayscale (IHDR + IDAT + IEND) -- minimal tapi valid.
PNG_1x1 = bytes.fromhex(
    "89504e470d0a1a0a"
    "0000000d49484452"  # IHDR len+type
    "0000000100000001"  # 1x1
    "0802000000"        # bitdepth 8, colortype 2 (truecolor)
    "907753de"          # CRC IHDR
    "0000000d49444154"  # IDAT len+type (zlib, 1 px)
    "789c6360000002000100e2 21bc33".replace(" ", "")
    + "0000000049454e44ae426082"  # IEND
)

GIF_1x1 = (
    b"GIF89a" + struct.pack("<HH", 1, 1)
    + b"\x80\x00\x00"                      # GCT flag, 2 colors
    + b"\x00\x00\x00\xff\xff\xff"          # GCT
    + b"\x2c" + struct.pack("<HHHH", 0, 0, 1, 1) + b"\x00"
    + b"\x02\x02\x44\x01\x00" + b"\x3b"
)

BMP_1x1 = (
    b"\x42\x4d" + struct.pack("<I", 58)      # 'BM' + filesize
    + struct.pack("<HH", 0, 0)               # reserved
    + struct.pack("<I", 54)                  # pixel data offset
    + struct.pack("<I", 40)                  # DIB header size
    + struct.pack("<ii", 1, 1)               # 1x1
    + struct.pack("<HH", 1, 24)              # planes, bpp
    + struct.pack("<I", 0)                   # compression
    + struct.pack("<I", 4) + struct.pack("<ii", 2835, 2835)
    + struct.pack("<I", 0) + struct.pack("<I", 0)
)

WBMP_1x1 = b"\x00" + b"\x00" + b"01" + b"01"   # type0, fixheader, w='01', h='01' (multi-byte FieldValue)

XBM_1x1 = b"#define x_width 1\n#define x_height 1\nstatic unsigned char x_bits[] = { 0x00 };\n"

SVG_1x1 = b'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"></svg>\n'

PDF_MIN = b"%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"


def jpeg_1x1() -> bytes:
    """JPEG 1x1 grayscale: SOI + DQT + SOF0 + payload-friendly.

    SOF0 WAJIB lengkap (presisi, tinggi, lebar, jumlah komponen + 3 byte per
    komponen), kalau tidak getimagesize() menolak (Unexpected end of JPEG).
    """
    dqt = b"\xff\xdb" + struct.pack(">H", 67) + b"\x00" + b"\x10" * 64
    sof0 = (
        b"\xff\xc0" + struct.pack(">H", 11)   # segment length
        + b"\x08"                              # presisi 8-bit
        + struct.pack(">HH", 1, 1)             # tinggi, lebar = 1x1
        + b"\x01"                              # 1 komponen
        + b"\x01\x11\x00"                      # id=1, sampling 1x1, quant table 0
    )
    return b"\xff\xd8" + dqt + sof0


HEADERS = {
    "png": PNG_1x1,
    "gif": GIF_1x1,
    "jpg": jpeg_1x1(),
    "jpeg": jpeg_1x1(),
    "bmp": BMP_1x1,
    "wbmp": WBMP_1x1,
    "xbm": XBM_1x1,
    "svg": SVG_1x1,
    "pdf": PDF_MIN,
}


def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1].lower() not in HEADERS:
        sys.stderr.write("usage: imgmagic.py {%s}\n" % "|".join(sorted(HEADERS)))
        return 2
    sys.stdout.buffer.write(HEADERS[sys.argv[1].lower()])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
