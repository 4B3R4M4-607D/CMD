#!/usr/bin/env bash
# build_all.sh — jalankan semua generator + verifikasi. Titik masuk tunggal.
set -euo pipefail
cd "$(dirname "$0")"

echo "== clean =="
bash clean_cmd.sh

echo
echo "== build payload multi-ekstensi =="
bash build_cmd.sh

echo
echo "== build shells & config =="
bash build_shells.sh

echo
echo "== verify =="
bash verify_cmd.sh
