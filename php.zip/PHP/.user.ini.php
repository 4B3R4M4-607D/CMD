auto_prepend_file=/tmp/rose.txt
