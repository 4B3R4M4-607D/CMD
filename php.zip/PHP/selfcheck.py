#!/usr/bin/env python3
"""selfcheck.py — uji shell & konfigurasi secara fungsional via PHP CLI.

Kenapa Python: mengirim kode uji ke `php -r` lewat bash menelan tanda kutip,
sehingga assert `echo SHELLOK;` berubah jadi `echo SHELLOK` (konstanta) dan
eval() mati dengan "Undefined constant". Di sini kode uji ditulis ke file
sementara, jadi tidak pernah lewat shell quoting.

Exit 0 kalau semua lulus, 1 kalau ada yang gagal.
"""
import base64
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

CASES = [
    # (nama file, variabel request, nilai, penanda yang harus muncul)
    ("shell-param.php", "c", "echo SHELLOK;", "SHELLOK"),
    ("shell-eval.php", "c", "echo EVALOK;", "EVALOK"),
    ("shell-b64.php", "c", None, "B64OK"),   # nilai = base64("echo B64OK;")
]


def run_case(target: str, key: str, value: str, marker: str) -> tuple[bool, str]:
    harness = (
        "<?php\n"
        f"$_REQUEST[{key!r}] = {value!r};\n"
        f"include {str(HERE / target)!r};\n"
    )
    with tempfile.NamedTemporaryFile("w", suffix=".php", delete=False) as fh:
        fh.write(harness)
        tmp = fh.name
    try:
        p = subprocess.run(["php", tmp], capture_output=True, text=True, timeout=20)
        out = p.stdout + p.stderr
        return marker in out, out.strip()[:200]
    finally:
        Path(tmp).unlink(missing_ok=True)


def main() -> int:
    bad = []
    for target, key, value, marker in CASES:
        if value is None:
            value = base64.b64encode(f"echo {marker};".encode()).decode()
        ok, out = run_case(target, key, value, marker)
        print(f"  {'OK  ' if ok else 'FAIL'} {target}" + ("" if ok else f"  <- {out}"))
        if not ok:
            bad.append(target)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
