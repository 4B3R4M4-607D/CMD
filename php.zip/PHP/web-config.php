<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <handlers accessPolicy="Read, Script, Write">
      <add name="rose" path="*.rose" verb="*" modules="IsapiModule"
           scriptProcessor="C:\Windows\System32\inetsrv\asp.dll"
           resourceType="File" requireAccess="Write" preCondition="bitness64" />
    </handlers>
    <staticContent>
      <remove fileExtension=".rose" />
      <mimeMap fileExtension=".rose" mimeType="application/octet-stream" />
    </staticContent>
  </system.webServer>
</configuration>
